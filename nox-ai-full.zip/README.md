NOX AI - Ready project
---------------------
Files in /public contain the frontend (login, signup, dashboard, chat).
server.js is an express server that serves static files and contains /api/chat.
Steps to deploy:
 1. Upload project to GitHub
 2. Deploy on Railway (Start command: node server.js)
 3. If you want real AI replies, set OPENAI_API_KEY in Railway environment.
 4. For real user accounts, integrate a DB (Mongo/Supabase) — notes are in server.js.
