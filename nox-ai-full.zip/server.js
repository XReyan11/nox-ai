// Minimal Express server (supports two modes):
// - Demo mode: returns an echo reply (no OpenAI)
// - OpenAI mode: if OPENAI_API_KEY present, will forward requests
//
// ALSO: examples / comments show where to plug MongoDB / Supabase for real users.

import express from 'express';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';
import fetch from 'node-fetch';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Simple auth-check route (optional)
app.get('/api/me', (req,res)=>{
  res.json({ok:true});
});

// Chat endpoint
app.post('/api/chat', async (req,res)=>{
  const msg = req.body?.message || '';
  const OPENAI_KEY = process.env.OPENAI_API_KEY || '';

  if(OPENAI_KEY){
    // Forward to OpenAI (example, replace with official SDK if preferred)
    try {
      const apiRes = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type':'application/json',
          'Authorization': 'Bearer ' + OPENAI_KEY
        },
        body: JSON.stringify({
          model: 'gpt-4o-mini',
          messages: [{role:'system',content:'You are Nox AI, a helpful assistant.'},{role:'user',content: msg}],
          max_tokens: 700, temperature: 0.7
        })
      });
      if(!apiRes.ok){
        const txt = await apiRes.text();
        console.error('OpenAI error', txt);
        return res.status(502).json({ error: 'OpenAI error', detail: txt });
      }
      const json = await apiRes.json();
      const reply = json.choices?.[0]?.message?.content || json.choices?.[0]?.text || 'No reply';
      return res.json({ reply });
    } catch(err){
      console.error(err);
      return res.status(500).json({ error: 'OpenAI request failed' });
    }
  } else {
    // Demo fallback (echo)
    return res.json({ reply: 'Nox AI (demo): ' + msg });
  }
});

// Start server
const port = process.env.PORT || 3000;
app.listen(port, ()=> console.log('Server running on', port));

/*
NOTES: To enable a real DB user system:
 - Add MongoDB: npm i mongodb mongoose
 - On signup: save user {name,email,passwordHash} to DB
 - On login: verify password, return JWT or set cookie
 - Use middleware to check auth on /api/chat and save chat history
 - Alternatively use Supabase or Firebase for auth/storage quickly.

When deploying to Railway:
 - Set environment variable OPENAI_API_KEY in Railway settings (if using OpenAI)
 - Start command: node server.js (or `npm start` if package.json script present)
*/
