// UI helpers and auth-aware small client
const menuBtn = document.getElementById('menuBtn');
const sideMenu = document.getElementById('sideMenu');
const overlay = document.getElementById('overlay');
const closeSide = document.getElementById('closeSide');
const sendBtn = document.getElementById('sendBtn');
const messageInput = document.getElementById('messageInput');
const chatBox = document.getElementById('chatBox');
const welcome = document.getElementById('welcome');
const plusBtn = document.getElementById('plusBtn');
const plusMenu = document.getElementById('plusMenu');
const moreBtn = document.getElementById('moreBtn');
const moreMenu = document.getElementById('moreMenu');

// Auth info
const curUser = JSON.parse(localStorage.getItem('nox_current_user')||'null');
if(window.location.pathname.endsWith('/chat.html') || window.location.pathname.endsWith('/dashboard.html')){
  if(!curUser){
    // not logged in — redirect to login
    location.href = 'login.html';
  } else {
    // show name in side
    const sideUser = document.getElementById('sideUser');
    const sideEmail = document.getElementById('sideEmail');
    if(sideUser) sideUser.innerText = curUser.name || 'User';
    if(sideEmail) sideEmail.innerText = curUser.email || '';
  }
}

// Side menu
function openSide(){ sideMenu.classList.add('open'); overlay.removeAttribute('hidden'); }
function closeSideMenu(){ sideMenu.classList.remove('open'); overlay.setAttribute('hidden',''); }
menuBtn?.addEventListener('click', ()=>{ sideMenu.classList.contains('open')? closeSideMenu(): openSide(); });
closeSide?.addEventListener('click', closeSideMenu);
overlay?.addEventListener('click', ()=>{ closeSideMenu(); hidePlusMenu(); hideMoreMenu(); });

// Plus menu
function showPlusMenu(){ plusMenu?.removeAttribute('hidden'); }
function hidePlusMenu(){ plusMenu?.setAttribute('hidden',''); }
function togglePlusMenu(){ plusMenu?.hasAttribute('hidden')? showPlusMenu(): hidePlusMenu(); }
plusBtn?.addEventListener('click',(e)=>{ e.stopPropagation(); togglePlusMenu(); });

// More menu
function toggleMoreMenu(){ if(!moreMenu) return; moreMenu.hasAttribute('hidden')? moreMenu.removeAttribute('hidden'): moreMenu.setAttribute('hidden',''); }
moreBtn?.addEventListener('click',(e)=>{ e.stopPropagation(); toggleMoreMenu(); });

// Chat logic
function addMessage(text, who='ai'){
  const div = document.createElement('div');
  div.className = 'msg ' + (who==='me'?'me':'ai');
  div.innerText = text;
  chatBox.appendChild(div);
  setTimeout(()=> chatBox.scrollTop = chatBox.scrollHeight, 40);
}

sendBtn?.addEventListener('click', sendMessage);
messageInput?.addEventListener('keydown',(e)=>{ if(e.key==='Enter') sendMessage(); });

async function sendMessage(){
  const text = messageInput?.value?.trim();
  if(!text) return;
  addMessage(text, 'me');
  messageInput.value = '';
  welcome.style.display = 'none';
  // optimistic loader
  const loader = document.createElement('div'); loader.className='msg ai'; loader.innerText='...'; chatBox.appendChild(loader); chatBox.scrollTop = chatBox.scrollHeight;
  try {
    const res = await fetch('/api/chat', { method:'POST', headers:{ 'Content-Type':'application/json' }, body: JSON.stringify({ message:text }) });
    loader.remove();
    if(!res.ok){ addMessage('Server error: '+res.status,'ai'); return; }
    const data = await res.json();
    addMessage(data.reply || data.message || 'No reply','ai');
  } catch(err){ loader.remove(); addMessage('Network error','ai'); console.error(err); }
}

// simple logout
document.getElementById('signout')?.addEventListener('click', ()=>{
  localStorage.removeItem('nox_current_user');
  location.href='login.html';
});

// dashboard nav
document.getElementById('goDashboard')?.addEventListener('click', ()=> location.href='dashboard.html');

// plus menu actions placeholders
document.getElementById('createImageBtn')?.addEventListener('click', ()=> { alert('Create Image — implement'); hidePlusMenu(); });
document.getElementById('imageToVideoBtn')?.addEventListener('click', ()=> { alert('Image→Video — implement'); hidePlusMenu(); });
document.getElementById('textToVideoBtn')?.addEventListener('click', ()=> { alert('Text→Video — implement'); hidePlusMenu(); });

